# Flashing Studio

A small, dependency-free flashing editor prepared for your own Cloudflare account. This is independent application code, not Variobend source code or a machine program exporter.

## Start locally

Install Node.js if it is not already available, open a terminal in this folder and run:

```sh
node server.mjs
```

Open http://127.0.0.1:4173. Keep the terminal running. The editor requires no AI or cloud account to work. Profile data stays in the tab until you download a JSON profile; reopening the page resets it to the example. Fonts are local/system fonts.

## Use the editor

1. Start from the custom-soffit example or select New drawing.
2. Use Draw new profile: click a start point, move to preview the next leg, and click to place it. The drawing recentres without changing its heading after each leg. Finish drawing, Enter or Escape ends the stroke. Extend end continues an existing drawing. Snapping to 5 mm / 15 degrees is optional; hold Shift to temporarily disable it. The two 15-degree rotation buttons rotate only on request. Undo restores earlier geometry.
3. Each leg after the first starts at a numbered bend. Positive turns are anticlockwise, negative turns clockwise, measured from flat. Opening angle is 180 minus the absolute turn. Convert a joint to Open hem and enter the required gap separately.
4. Click a dimension on the drawing to edit it in place, or use the master editor at the side. Side A is the left face of the directed path START to END; side B is the right face. The orange line marks the selected face and follows the geometry when rotated. This face selection is distinct from the finish name (e.g. Lignite). Older profiles import with colour side unconfirmed.
5. The bending procedure now illustrates the cumulative shape after each operation. Each operation has a joint, stage, target angle from flat, physical handling, sheet support and operator note. Add stage after allows a partial bend followed by a later finish. Reordering or editing targets clears handling/support confirmations. The shape cards do not simulate machine motion, collision, gravity, sheet rigidity or deformation.
6. Expand Order details to enter customer, site, contact, form/job number, dates, delivery and pitch. Flashing form SVG exports those details with the drawing, colour side, dimensions, quantity, sheet length, girth and notes in a form inspired by the supplied blank form. It does not reuse the supplier's logo or pretend to be their official form. Print / PDF form prints this form. Procedure SVG and Print procedure export the illustrated sequence separately. Draft email opens the user's mail application with a textual summary; attach the exported files manually.

Reordering clears handling confirmations because the sheet's preceding state changed. Geometry changes reset the sequence to drawing order. That order is a drafting convenience, not an automatically optimised or validated bending order.

## Cloudflare deployment

The project uses a Worker with static assets. From this directory, with Node.js/npm installed and your Cloudflare account available:

```sh
npx wrangler login
npx wrangler deploy
```

Wrangler prints the deployed URL. `wrangler.jsonc` serves only `dist/` as public assets, with `/api/*` routed through `worker.mjs`. No account ID or secret is included. Authentication and deployment have not been performed in this workspace. The local preview does not validate Cloudflare deployment.

Cloudflare documentation: [static assets](https://developers.cloudflare.com/workers/static-assets/), [routing configuration](https://developers.cloudflare.com/workers/static-assets/binding/).

## Optional Workers AI extension

The editor works without AI. `worker.mjs` includes a disabled-by-default POST `/api/review` adapter for a future trusted server caller. It validates the profile, adds deterministic checks and asks for review suggestions. It does not change the drawing or approve a sequence.

To enable it later:

1. Add `"ai": { "binding": "AI" }` to `wrangler.jsonc`.
2. Add an `AI_MODEL` variable containing a model currently supported by Workers AI.
3. Set a secret with `npx wrangler secret put AI_REVIEW_TOKEN`.
4. Redeploy. A trusted caller supplies `Authorization: Bearer <secret>` and the profile JSON. Never put that secret into `dist/` or any public browser script. Before exposing AI directly to website visitors, add per-user authentication and usage controls; the present adapter deliberately has no browser caller.

AI output is unverified prose. It cannot replace physical machine geometry, material tables, or deterministic collision checks. [Workers AI bindings documentation](https://developers.cloudflare.com/workers-ai/configuration/bindings/).

## Known scope and evidence

- Machine: operator-described single-action Variobend, nominal working length 6,400 mm. Only the stated length limit is implemented. No thickness capacity is assumed.
- Custom soffit example: nominal legs 15, 80, 40, 25, 80, 10 mm; quantity 1; length 2,700 mm; 0.55 mm steel. The last 10 mm return is inferred from the displayed 250 mm girth minus the other visible lengths and should be checked against the source. Observed order: first hem prebend/close, last hem prebend/close, B4, B3, B2.
- Operator explicitly confirmed that operation 6 (B3) physically requires both spin and flip for this sequence. Other transitions remain unconfirmed. This does not prove all possible orders require that movement.
- The custom soffit's 2 mm hem gaps are editable draft defaults, not confirmed measurements. The separate earlier profile 35786 does have an operator-approved 2 mm open-crush setting.
- Drawing is nominal centreline geometry. Terminal hems are visually offset for readability, not drawn at physical gap scale. Flat-pattern bend deductions/allowances and material stretch are not calculated.
- No collision analysis, machine motion, grip/clearance checks, automatic sequence optimiser, direct email delivery or SLINET export is implemented.

## Ridge reference added 16 September 2026

The page includes 11 illustrated operations transcribed from the supplied `Bending Sequence on a Ridge explanation.pdf`. Images in `dist/reference/` are extracted from that user-provided guide. They are reference illustrations, not outputs of our geometry engine. The guide's first numbered section is an overview, so the app normalises the actual operation numbering to 1–11.

Confirmed reference principles: start with sheet support inside; perform the adjacent fold before changing ends; use external support to avoid additional spins; distinguish simulator movement from physical movement; make one physical spin at the operation corresponding to document section 9; finish structural folds before flattening the two 140-degree folds. Choosing Ridge reference method activates a check that flattening operations come after structural operations. It also displays the contextual support and interference cautions.

The user supplied usual dimensions: 200 mm main face on each side, 40 mm return, 30 mm downstand, 10 mm crush. Finished angles and gaps remain unknown. The PDF's approximate 200–300 mm narrow-profile warning is not defined clearly enough to become a hard threshold (total girth versus distance between folds). No automatic ridge geometry or supposedly collision-free sequence has been invented. A reference method is not proof that any edited profile can use it.

## Extending this foundation

`dist/model.js` owns the portable profile format, geometry, cumulative stage states and checks. `dist/drawing.js` renders the section and form/procedure SVGs. `dist/ridge-guide.js` records the supplied method. `dist/app.js` owns the UI. `worker.mjs` owns optional AI review. Keep measured machine limitations as structured data with units and evidence. Add tooling geometry and material capacity tables before building a search over candidate sequences. Rank only feasible candidates by physical handling cost.

The page optionally exposes a read-only `read_flashing_profile` WebMCP tool when the browser supports it. WebMCP runtime validation was unavailable; it is not required by the editor.

## Verification

```sh
node --test --test-isolation=none tests/model.test.mjs
node --check dist/app.js
node --check dist/model.js
node --check worker.mjs
```

22 automated tests cover geometry, backwards-compatible files, staged folds, contextual flattening order, rotation without unintended heading changes, centring, colour-side rendering, SVG metadata/escaping, sequence completeness and the AI adapter. Browser checks verified on-drawing editing, colour-side selection, requested rotation, appending without rotation, and drawing with a live preview. SVG form and procedure renders were visually inspected. Real Workers AI, Cloudflare deployment and the browser print-to-PDF dialog have not been exercised.
