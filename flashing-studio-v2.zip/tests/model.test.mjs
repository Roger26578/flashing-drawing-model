import test from 'node:test';
import assert from 'node:assert/strict';
import {example,blank,points,validate,checks,defaultSequence,summary,normalise,appendLeg,rotate,stageProfile,stageTarget} from '../dist/model.js';
import {orderSvg,procedureSvg,layout,section} from '../dist/drawing.js';
import {ridgeGuide} from '../dist/ridge-guide.js';
import worker from '../worker.mjs';
test('observed custom-soffit dimensions and handling are preserved',()=>{
  const p=example();validate(p);assert.equal(p.legs.reduce((a,l)=>a+l.length,0),250);
  assert.deepEqual(p.sequence.map(s=>s.joint),[1,1,5,5,4,3,2]);
  assert.equal(p.sequence[5].handling,'both');assert.equal(checks(p).filter(c=>c.level==='error').length,0);
  assert.equal(p.sequence.filter(s=>s.handling==='unknown').length,6);
});
test('signed turns produce independent known right-angle coordinates',()=>{
  const p=blank();p.heading=0;p.legs=[{length:100,angle:0,type:'bend',gap:2},{length:50,angle:90,type:'bend',gap:2},{length:25,angle:-90,type:'bend',gap:2}];
  const result=points(p);assert.deepEqual(result.slice(0,3),[{x:0,y:0},{x:100,y:0},{x:100,y:50}]);assert.equal(result[3].x,125);assert.equal(result[3].y,50);
});
test('hem folds back independent of user-entered ordinary bend angle',()=>{
  const p=blank();p.legs.push({length:25,angle:177,type:'hem',gap:2});
  const end=points(p).at(-1);assert.ok(Math.abs(end.x-75)<1e-8);assert.ok(Math.abs(end.y)<1e-8);
});
test('length capacity flags only an actual exceedance',()=>{
  const p=example();p.length=6400;assert.equal(checks(p).filter(c=>c.level==='error').length,0);
  p.length=6401;assert.match(checks(p)[0].text,/exceeds/);
});
test('missing, duplicated and reversed hem operations are detected',()=>{
  for(const mutate of [p=>p.sequence.shift(),p=>p.sequence.push({...p.sequence[0]}),p=>[p.sequence[0],p.sequence[1]]=[p.sequence[1],p.sequence[0]]]){const p=example();mutate(p);assert.ok(checks(p).some(c=>c.level==='error'));}
});
test('draft order does not invent handling confirmations',()=>{
  const p=example();p.sequence=defaultSequence(p);assert.ok(p.sequence.every(s=>s.handling==='unknown'));assert.equal(checks(p).filter(c=>c.level==='error').length,0);
});
test('profile JSON roundtrips and rejects corrupt data',()=>{
  const p=example();assert.deepEqual(validate(JSON.parse(JSON.stringify(p))),p);
  for(const mutate of [p=>p.legs[0].length=-1,p=>p.quantity=1.5,p=>p.sequence[0].joint=99,p=>p.legs[1].gap=Infinity,p=>p.version=2,p=>p.legs=[]]){const bad=example();mutate(bad);assert.throws(()=>validate(bad));}
});
test('email summary includes dimensions, operation and limits',()=>{
  const text=summary(example());assert.match(text,/250 mm/);assert.match(text,/6\. B3 Bend — Spin \+ flip/);assert.match(text,/No collision/);
});
test('worker has no AI access by default and protects configured endpoint',async()=>{
  let called=false;const request=()=>new Request('https://example.test/api/review',{method:'POST',body:JSON.stringify(example())});
  assert.equal((await worker.fetch(request(),{})).status,503);
  const env={AI:{run:async()=>{called=true;return {response:'Draft suggestion'};}},AI_MODEL:'configured-model',AI_REVIEW_TOKEN:'test-token'};
  assert.equal((await worker.fetch(request(),env)).status,401);assert.equal(called,false);
  const good=new Request('https://example.test/api/review',{method:'POST',headers:{Authorization:'Bearer test-token'},body:JSON.stringify(example())});
  const response=await worker.fetch(good,env);assert.equal(response.status,200);assert.equal((await response.json()).status,'suggestion-only');assert.equal(called,true);
});
test('worker rejects malformed authorised profiles and unknown routes',async()=>{
  const env={AI:{},AI_MODEL:'configured-model',AI_REVIEW_TOKEN:'test-token'};
  const request=new Request('https://example.test/api/review',{method:'POST',headers:{Authorization:'Bearer test-token'},body:'{"version":1}'});
  assert.equal((await worker.fetch(request,env)).status,400);
  assert.equal((await worker.fetch(new Request('https://example.test/api/other'),{})).status,404);
});
test('old profile files gain new fields without inventing a colour side',()=>{
  const old=example(),p=normalise(old);validate(p);assert.equal(p.colourSide,'unknown');assert.equal(p.order.customer,'');assert.equal(p.sequence[0].target,140);assert.equal(p.sequence[5].handling,'both');assert.equal(old.colourSide,undefined);
});
test('appending preserves heading and existing vertices',()=>{
  const p=blank();p.heading=35;const before=points(p);appendLeg(p,40,125);assert.equal(p.heading,35);assert.equal(p.legs[1].angle,90);assert.deepEqual(points(p).slice(0,2),before);
  appendLeg(p,30,125);assert.equal(p.legs[2].angle,0);validate(p);
});
test('15 degree rotation is reversible and preserves colour side and lengths',()=>{
  const p=normalise(example());p.colourSide='B';const before=points(p);rotate(p,15);assert.equal(p.heading,-165);rotate(p,-15);points(p).forEach((v,i)=>{assert.ok(Math.abs(v.x-before[i].x)<1e-8);assert.ok(Math.abs(v.y-before[i].y)<1e-8);});assert.equal(p.colourSide,'B');assert.equal(p.legs.reduce((s,l)=>s+l.length,0),250);
});
test('cumulative stages retain prior targets and leave future bends flat',()=>{
  const p=normalise(example());const first=stageProfile(p,0);assert.equal(first.legs[1].angle,140);assert.ok(first.legs.slice(2).every(l=>l.angle===0));const closed=stageProfile(p,1);assert.equal(closed.legs[1].angle,180);assert.equal(closed.legs[1].type,'hem');const finished=stageProfile(p,p.sequence.length-1);assert.deepEqual(points(finished),points(p));
});
test('partial ordinary bends and final flattening support repeated operations',()=>{
  const p=normalise(blank());p.legs.push({length:40,angle:180,type:'bend',gap:2});p.sequence=[{joint:1,stage:'Prebend',target:140,handling:'none',support:'outside',note:''},{joint:1,stage:'Flatten',target:180,handling:'none',support:'outside',note:''}];validate(p);assert.equal(checks(p).filter(c=>c.level==='error').length,0);assert.equal(stageProfile(p,0).legs[1].angle,140);assert.equal(stageProfile(p,1).legs[1].angle,180);
});
test('ridge flattening rule is contextual and catches early flattening',()=>{
  const p=normalise(example());p.sequence[0].stage='Flatten';p.procedure='ridge';assert.ok(checks(p).some(c=>/leave the final flattening/.test(c.text)));p.procedure='general';assert.ok(!checks(p).some(c=>/leave the final flattening/.test(c.text)));
});
test('centred layout fits points and makes no rotational transform',()=>{
  const p=example(),v=layout(p);const xs=v.ps.map(a=>a.x),ys=v.ps.map(a=>a.y);assert.ok(Math.abs((Math.min(...xs)+Math.max(...xs))/2-450)<1e-8);assert.ok(Math.abs((Math.min(...ys)+Math.max(...ys))/2-250)<1e-8);assert.ok(v.ps.every(a=>a.x>=80&&a.x<=820&&a.y>=80&&a.y<=420));
});
test('form SVG contains escaped job data, physical face, quantities and full long fields',()=>{
  const p=normalise(example());p.colourSide='A';p.colour='Lignite';p.order.customer='A&B <Customer>';p.order.contact='123456789012345678901234567890';p.order.email='name-with-long-address@example.test';p.order.number='38753';const svg=orderSvg(p);assert.match(svg,/FLASHING FORM/);assert.match(svg,/38753/);assert.match(svg,/A&amp;B &lt;Customer&gt;/);assert.match(svg,/2700 mm/);assert.match(svg,/Lignite/);assert.match(svg,/colour side A/);assert.match(svg,/stroke="#d46b24"/);assert.match(svg,/name-with-long-address@example.test/);assert.match(svg,/123456789012345678901234567890/);assert.ok(!svg.includes('data-edit'));
});
test('procedure export grows for long notes and preserves stage/support',()=>{
  const p=normalise(example());p.sequence[0].support='outside';p.sequence[0].note='Support the sheet. '.repeat(50);const svg=procedureSvg(p);assert.match(svg,/Operator support outside/);assert.match(svg,/140°/);assert.ok(Number(svg.match(/height="(\d+)"/)[1])>1900);
});
test('colour-face swapping changes only face geometry',()=>{
  const p=normalise(example());p.colourSide='A';const a=section(p).body;p.colourSide='B';const b=section(p).body;assert.notEqual(a,b);assert.deepEqual(points(p),points(example()));
});
test('reference preserves one spin and two final flattening operations',()=>{
  assert.equal(ridgeGuide.length,11);assert.equal(ridgeGuide.filter(s=>s.spin).length,1);assert.equal(ridgeGuide[7].spin,true);assert.match(ridgeGuide[9].title,/Flatten/);assert.match(ridgeGuide[10].title,/Flatten/);
});
test('new metadata rejects nonfinite targets and unsupported support positions',()=>{
  for(const edit of [p=>p.sequence[0].target=Infinity,p=>p.sequence[0].support='magic',p=>p.colourSide='outside',p=>p.order.customer=123]){const p=normalise(example());edit(p);assert.throws(()=>validate(p));}
});
